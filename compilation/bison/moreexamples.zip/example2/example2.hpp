#ifndef EXAMPLE2
#define EXAMPLE2

    typedef union
    {
        int i;
        char c;
    }u;
    
    #define YYSTYPE u
    
#endif
