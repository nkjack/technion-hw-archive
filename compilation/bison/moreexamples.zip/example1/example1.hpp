#ifndef EXAMPLE1
#define EXAMPLE1

    #define YYSTYPE bool
    
#endif
